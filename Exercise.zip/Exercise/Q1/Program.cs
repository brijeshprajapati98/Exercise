﻿using System;

namespace excrcise
{
    class text1
    {
        static void Main(string[] args)
        {
            int a = 5, b = 10;               
             int c = a ;
                 a = b ;
                 b = c ;          
            Console.WriteLine(a);
            Console.WriteLine(b);
            Console.ReadLine(); 
        }
    }
}
